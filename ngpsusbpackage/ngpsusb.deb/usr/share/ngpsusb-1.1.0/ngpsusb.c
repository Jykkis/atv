/*
 * NovAtel GPS USB to RS232 serial adaptor driver
 */

#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/tty.h>
#include <linux/tty_flip.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/usb.h>
#include <linux/uaccess.h>
#include <linux/usb/serial.h>
#include <linux/version.h>

/*
 * Version Information
// */
#define DRIVER_VERSION "v1.1.0"
#define DRIVER_DESC "NovAtel GPS Receiver virtual serial port driver"


static const struct usb_device_id id_table[] = {
{ USB_DEVICE(0x09d7, 0x0100) },     /* NovAtel GPS USB interface */
{}	                            /* Terminating Entry */
};

MODULE_DEVICE_TABLE(usb, id_table);

struct ngps_port_private {
__u8	bInterfaceNumber;
};


#if LINUX_VERSION_CODE < KERNEL_VERSION(3,4,0)

	static struct usb_driver ngpsusb_driver = {
	.name	= "ngpsusb",
	.probe	= usb_serial_probe,
	.disconnect	= usb_serial_disconnect,
	.id_table	= id_table,
	.no_dynamic_id	= 1,
	};

#endif

static struct usb_serial_driver ngpsser_driver= {
	.driver = {
	.owner =	THIS_MODULE,
	.name = "ngpsser",
	},
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,4,0)
	.usb_driver	= &ngpsusb_driver,
#endif
	.id_table	= id_table,
	.num_ports	= 3,
//	.attach	= ngps_startup,
//	.release	= ngps_release,	
};


  static struct usb_serial_driver * const serial_drivers[] = {
          &ngpsser_driver, NULL
  };


static int __init ngps_init(void)
{
	int retval;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,4,0)

	retval = usb_serial_register_drivers(serial_drivers, KBUILD_MODNAME, id_table);

#else

	retval = usb_serial_register(&ngpsser_driver);

	if (retval)
	{
		return retval;
	}

	retval = usb_register(&ngpsusb_driver);

	if (retval)
	{
		usb_serial_deregister(&ngpsser_driver);
		return retval;
	}


#endif 



	/* Success */

	printk(KERN_INFO KBUILD_MODNAME ": " DRIVER_VERSION ": " DRIVER_DESC "\n");

	return retval;
}

static void __exit ngps_exit(void)
{

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,4,0)
        usb_serial_deregister_drivers(serial_drivers);
#else
	usb_deregister(&ngpsusb_driver);
	usb_serial_deregister(&ngpsser_driver);

#endif

}

module_init(ngps_init);
module_exit(ngps_exit);

MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_VERSION(DRIVER_VERSION);
MODULE_LICENSE("GPL v2");

